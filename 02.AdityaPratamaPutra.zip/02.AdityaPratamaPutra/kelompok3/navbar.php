
<nav class="navbar navbar-expand-lg nav-purple">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
		<div class="navbar-nav">
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'home' ? 'active' : '' ?>" href="index.php">Beranda</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'sejarah' ? 'active' : '' ?>" href="sejarah.php">Sejarah Sekolah</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'artikel' ? 'active' : '' ?>" href="artikel.php">Info Sekolah</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'kurikulum' ? 'active' : '' ?>" href="kurikulum.php">Kurikulum</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'visi_misi' ? 'active' : '' ?>" href="visi_misi.php">Visi Misi</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'guru' ? 'active' : '' ?>" href="guru.php">Tenaga Pendidikan</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'jurusan' ? 'active' : '' ?>" href="jurusan.php">Jurusan</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'ekskul' ? 'active' : '' ?>" href="ekskul.php">Ekskul</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'galeri' ? 'active' : '' ?>" href="galeri.php">Galeri Kegiatan</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'prestasi' ? 'active' : '' ?>" href="prestasi.php">Prestasi Sekolah</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'bukutamu' ? 'active' : '' ?>" href="bukutamu.php">Kritik dan Saran</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'ppdb' ? 'active' : '' ?>" href="ppdb.php">Info PPDB</a>
			<a class="nav-item nav-link text-white navlink <?= $aktif == 'kontak' ? 'active' : '' ?>" href="kontak.php">Kontak</a>
		</div>
	</div>
</nav>