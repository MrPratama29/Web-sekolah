<?php 

require_once 'koneksi.php';
$query = mysqli_query($koneksi, "SELECT * FROM tbl_ppdb");
$aktif = 'ppdb';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>PPDB - SMK YAJ DEPOK</title>
	<link rel="stylesheet" href="resources/fonts/stylesheet.css">
	<link rel="stylesheet" href="resources/css/bootstrap.min.css">
	<link rel="stylesheet" href="resources/css/style.css">
</head>
<body>
	<div class="container bg-light">
		<!-- top bar -->
		<?php require_once 'top-bar.php'?>
			
		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>

		<!-- content -->
		<div class="row p-3">
			<div class="col-md-8">
				<div class="title mb-3">
					Info Sekolah
				</div>
				<?php while($ppdb = mysqli_fetch_assoc($query)) : ?>
				<div class="artikel">
				
					<div class="detail">
						<div class="clearfix" style="text-align: justify;">
							<img src="images/ppdb/<?= $ppdb['ppdb'] ?>" alt="" width="80%" class="float-none mr-2">
							
						</div>
					</div>
					<hr>
				</div>
				<?php endwhile; ?>
			</div>
			<?php require_once 'sidebar.php'; ?>
		</div>
		<?php require 'footer.php';?>