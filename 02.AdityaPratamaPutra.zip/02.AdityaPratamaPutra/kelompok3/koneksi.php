<?php 
session_start();

$koneksi = mysqli_connect('localhost', 'root', '', 'dbk3v2') or die('gagal konek');

?>